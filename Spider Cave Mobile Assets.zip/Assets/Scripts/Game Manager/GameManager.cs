using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class GameManager : MonoBehaviour
{
    public void Start()
    {
        
    }
    public void Update()
    {
    }
    public void PlayAgain()
    {
        SceneManager.LoadScene(2);
    }
    public void Exit()
    {
        SceneManager.LoadScene(0);
    }
}

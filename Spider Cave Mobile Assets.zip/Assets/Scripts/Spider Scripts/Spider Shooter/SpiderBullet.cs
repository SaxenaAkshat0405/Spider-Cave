﻿using UnityEngine;
using UnityEngine.SceneManagement;
using System.Collections;

public class SpiderBullet : MonoBehaviour {

	void OnTriggerEnter2D(Collider2D target) {
		if (target.tag == "Player") {
			Destroy(target.gameObject);
			Destroy(gameObject);
			SceneManager.LoadScene(4);
		}

		if (target.tag == "Ground") {
			Destroy(gameObject);
		}

	}

}
